Tulkojums Sypex Dumper 2 :: http://sypex.net/

Uzstādīšana:
1. Novietojiet lng_lv.php failu no arhīva Sypex /lang direktorijā
2. Atveriet saiti: http://jūsu_sypex/lang/update.php