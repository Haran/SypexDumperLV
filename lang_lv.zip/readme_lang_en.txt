Unzip and upload the contents of the archive to the directory "sxd/lang/".
Run http://.../sxd/lang/update.php
